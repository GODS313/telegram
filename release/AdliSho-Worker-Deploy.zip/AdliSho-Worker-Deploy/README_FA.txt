Worker جدید AdliSho
====================

مخزن متصل به Cloudflare:
https://github.com/GODS313/telegram

فایل آماده Worker داخل این بسته:
cloudflare-worker/src/index.js

Secretهای لازم در Cloudflare:
TG_BOT_TOKEN
TG_CHAT_ID
RELAY_SECRET

نکته مهم:
مقدار RELAY_SECRET در Cloudflare باید دقیقاً با مقدار داخل پنل سایت در
مدیریت > تنظیمات و Worker
یکسان باشد.

پس از Deploy:
1) آدرس نهایی workers.dev را از صفحه Deploy کپی کنید.
2) در پنل سایت، بخش تنظیمات و Worker وارد کنید.
3) ابتدا «بررسی سلامت» و سپس «ارسال پیام آزمایشی» را بزنید.

این نسخه فقط وضعیت‌های عملیاتی و کد رهگیری را ارسال می‌کند و اطلاعات حساس،
شماره تلفن، کد ملی، IP، دستگاه، سلفی و ویدیو را به تلگرام نمی‌فرستد.
