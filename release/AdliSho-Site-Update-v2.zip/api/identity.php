<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['ok'=>false,'message'=>'روش نامعتبر'],405);
if(!verify_csrf($_POST['csrf']??null))json_response(['ok'=>false,'message'=>'صفحه را تازه کنید'],419);
$code=strtoupper(trim((string)($_POST['code']??'')));$app=find_application($code);
if(!$app)json_response(['ok'=>false,'message'=>'پرونده معتبر نیست'],404);
if(($_POST['media_consent']??'')!=='1')json_response(['ok'=>false,'message'=>'رضایت ثبت تصویر و ویدیو لازم است'],422);
ensure_dirs();
function save_identity_file(string $field,array $allowed,int $max): string {
  if(empty($_FILES[$field]['name'])||$_FILES[$field]['error']!==UPLOAD_ERR_OK)json_response(['ok'=>false,'message'=>'فایل '.$field.' دریافت نشد'],422);
  if((int)$_FILES[$field]['size']>$max)json_response(['ok'=>false,'message'=>'حجم فایل '.$field.' بیش از حد مجاز است'],422);
  $mime=(new finfo(FILEINFO_MIME_TYPE))->file($_FILES[$field]['tmp_name']);
  if(!isset($allowed[$mime]))json_response(['ok'=>false,'message'=>'فرمت فایل '.$field.' مجاز نیست'],422);
  $name=bin2hex(random_bytes(16)).'.'.$allowed[$mime];
  if(!move_uploaded_file($_FILES[$field]['tmp_name'],IDENTITY_DIR.'/'.$name))json_response(['ok'=>false,'message'=>'ذخیره فایل انجام نشد'],500);
  @chmod(IDENTITY_DIR.'/'.$name,0640);return $name;
}
$selfie=save_identity_file('selfie',['image/jpeg'=>'jpg','image/png'=>'png'],5*1024*1024);
$video=save_identity_file('video',['video/mp4'=>'mp4','video/webm'=>'webm','video/quicktime'=>'mov'],15*1024*1024);
save_jsonl('identity.jsonl',['code'=>$code,'created_at'=>date(DATE_ATOM),'selfie'=>$selfie,'video'=>$video,'status'=>'pending_manual_review']);
worker_send('/api/follow',['code'=>$code,'time'=>date(DATE_ATOM),'event'=>'identity_uploaded','note'=>'رسانه احراز برای بررسی دستی دریافت شد.']);
json_response(['ok'=>true]);
