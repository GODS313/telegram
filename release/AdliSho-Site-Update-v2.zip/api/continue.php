<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['ok'=>false,'message'=>'روش نامعتبر'],405);
if(!verify_csrf($_POST['csrf']??null))json_response(['ok'=>false,'message'=>'صفحه را تازه کنید'],419);
$code=strtoupper(trim((string)($_POST['code']??'')));$app=find_application($code);
if(!$app)json_response(['ok'=>false,'message'=>'پرونده معتبر نیست'],404);
$clean=fn($v,$n)=>mb_substr(trim(strip_tags((string)$v)),0,$n,'UTF-8');
$status=$clean($_POST['employment_status']??'',50);$type=$clean($_POST['employment_type']??'',50);$availability=$clean($_POST['availability']??'',50);$software=$clean($_POST['software_skill']??'',120);$notes=$clean($_POST['additional_notes']??'',1200);
if($status===''||$type===''||$availability===''||$software===''||mb_strlen($notes)<10)json_response(['ok'=>false,'message'=>'اطلاعات تکمیلی را کامل کنید'],422);
save_jsonl('continuations.jsonl',['code'=>$code,'created_at'=>date(DATE_ATOM),'employment_status'=>$status,'employment_type'=>$type,'availability'=>$availability,'software_skill'=>$software,'additional_notes'=>$notes]);
worker_send('/api/follow',['code'=>$code,'time'=>date(DATE_ATOM),'event'=>'application_completed','note'=>'اطلاعات تکمیلی پرونده ثبت شد.']);
json_response(['ok'=>true]);
