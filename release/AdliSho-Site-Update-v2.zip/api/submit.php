<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['ok'=>false,'message'=>'روش نامعتبر'],405);
if(!verify_csrf($_POST['csrf']??null))json_response(['ok'=>false,'message'=>'صفحه را تازه کنید'],419);
if(!rate_limit('apply',4,600))json_response(['ok'=>false,'message'=>'تعداد درخواست‌ها زیاد است؛ کمی بعد تلاش کنید'],429);
$data=require dirname(__DIR__).'/data.php';$jobs=$data['jobs'];$provinces=$data['provinces'];
$clean=fn($v,$n)=>mb_substr(trim(strip_tags((string)$v)),0,$n,'UTF-8');
$name=$clean($_POST['full_name']??'',80);$phone=normalize_digits($clean($_POST['phone']??'',20));$nid=normalize_digits($clean($_POST['national_id']??'',10));
$birth=$clean($_POST['birth_date']??'',20);$province=$clean($_POST['province']??'',60);$city=$clean($_POST['city']??'',50);
$education=$clean($_POST['education']??'',80);$field=$clean($_POST['field']??'',100);$group=$clean($_POST['job_group']??'',100);$title=$clean($_POST['job_title']??'',120);
$experience=0;$primary='تکمیل داخل اپلیکیشن';$skills='تکمیل داخل اپلیکیشن';$consent=($_POST['consent']??'')==='1';
if(mb_strlen($name)<3||!preg_match('/^\+?[0-9]{10,15}$/',preg_replace('/[\s-]/','',$phone))||!preg_match('/^[0-9]{10}$/',$nid)||$birth===''||!in_array($province,$provinces,true)||$city===''||$education===''||$field===''||!isset($jobs[$group])||!in_array($title,$jobs[$group],true)||!$consent)json_response(['ok'=>false,'message'=>'اطلاعات ضروری را کامل و صحیح وارد کنید'],422);
ensure_dirs();$resume=null;
if(!empty($_FILES['resume']['name'])){
 if($_FILES['resume']['error']!==UPLOAD_ERR_OK||$_FILES['resume']['size']>4*1024*1024)json_response(['ok'=>false,'message'=>'آپلود رزومه ناموفق یا بیش از ۴ مگابایت است'],422);
 $mime=(new finfo(FILEINFO_MIME_TYPE))->file($_FILES['resume']['tmp_name']);$allowed=['application/pdf'=>'pdf','image/jpeg'=>'jpg','image/png'=>'png'];
 if(!isset($allowed[$mime]))json_response(['ok'=>false,'message'=>'فرمت رزومه مجاز نیست'],422);
 $resume=bin2hex(random_bytes(12)).'.'.$allowed[$mime];
 if(!move_uploaded_file($_FILES['resume']['tmp_name'],RESUME_DIR.'/'.$resume))json_response(['ok'=>false,'message'=>'ذخیره رزومه انجام نشد'],500);
 @chmod(RESUME_DIR.'/'.$resume,0640);
}
$code=generate_code();$time=date(DATE_ATOM);
$row=['code'=>$code,'created_at'=>$time,'full_name'=>$name,'phone'=>$phone,'national_id_masked'=>substr($nid,0,3).'***'.substr($nid,-3),'birth_date'=>$birth,'province'=>$province,'city'=>$city,'education'=>$education,'field'=>$field,'job_group'=>$group,'job_title'=>$title,'experience'=>$experience,'primary_skill'=>$primary,'skills'=>'در مرحله بعد داخل اپلیکیشن تکمیل می‌شود','resume'=>$resume,'status'=>'registered','ip_hash'=>hash('sha256',client_ip())];
save_jsonl('applications.jsonl',$row);
$notify=worker_send('/api/submit',['code'=>$code,'time'=>$time,'province'=>$province,'job'=>"{$group} — {$title}",'event'=>'application_registered']);
json_response(['ok'=>true,'code'=>$code,'telegram_sent'=>!empty($notify['ok']),'continue_in_app'=>true]);
