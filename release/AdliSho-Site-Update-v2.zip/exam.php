<?php
require __DIR__.'/bootstrap.php';

$code=strtoupper(trim((string)($_GET['code']??$_POST['code']??'')));$app=find_application($code);if(!$app)http_response_code(404);
if($app && (!has_record('continuations.jsonl',$code) || !has_record('identity.jsonl',$code))){http_response_code(403);die('مراحل قبل کامل نشده است.');}
$all=require __DIR__.'/questions.php';$qs=$app?$all[$app['job_group']]??[]:[];$error='';
if($_SERVER['REQUEST_METHOD']==='POST'&&$app){
 if(!verify_csrf($_POST['csrf']??null))$error='نشست آزمون منقضی شده است.';
 else{$correct=0;$answers=[];foreach($qs as $i=>$q){$c=isset($_POST['q'.$i])?(int)$_POST['q'.$i]:-1;if($c===$q['a'])$correct++;$answers[]=$c;}
 $score=(int)round(($correct/max(1,count($qs)))*100);$row=['code'=>$code,'job_group'=>$app['job_group'],'score'=>$score,'correct'=>$correct,'total'=>count($qs),'created_at'=>date(DATE_ATOM),'answers'=>$answers];save_jsonl('exam_results.jsonl',$row);
 worker_send('/api/follow',['code'=>$code,'time'=>date(DATE_ATOM),'event'=>'exam_completed','note'=>"امتیاز آزمون: {$score} از 100"]);
 header('Location: result.php?code='.rawurlencode($code));exit;}
}
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>آزمون استخدام اداری برق</title><link rel="stylesheet" href="assets/style.css"></head><body><main class="section shell exam-wrap">
<?php if(!$app):?><section class="panel"><h1>پرونده پیدا نشد</h1></section><?php else:?><section class="panel"><span class="eyebrow"><?=h($app['job_group'])?></span><h1>آزمون <?=h($app['job_title'])?></h1><p class="muted"><?=count($qs)?> سؤال عمومی و تخصصی</p><?php if($error):?><p class="error"><?=h($error)?></p><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="code" value="<?=h($code)?>">
<?php foreach($qs as $i=>$q):?><div class="card question"><b><?=($i+1)?>. <?=h($q['q'])?></b><div class="options"><?php foreach($q['o'] as $j=>$o):?><label class="option"><input type="radio" name="q<?=$i?>" value="<?=$j?>" required><span><?=h($o)?></span></label><?php endforeach;?></div></div><?php endforeach;?>
<button class="btn primary full">ثبت پاسخ‌ها و مشاهده نتیجه</button></form></section><?php endif;?></main></body></html>
