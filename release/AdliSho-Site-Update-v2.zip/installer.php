<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
$installed=file_exists(__DIR__.'/config.local.php');$justInstalled=false;$error='';
if($_SERVER['REQUEST_METHOD']==='POST'&&!$installed){
  if(!verify_csrf($_POST['csrf']??null))$error='نشست نصب منقضی شده است.';
  else{
    $pass=(string)($_POST['admin_password']??'');
    $base=rtrim(trim((string)($_POST['base_url']??'')),'/');
    $worker=rtrim(trim((string)($_POST['worker_url']??'')),'/');
    $official=!empty($_POST['official_authorized']);
    $authTitle=trim((string)($_POST['authorization_title']??''));
    $authRef=trim((string)($_POST['authorization_reference']??''));
    if(strlen($pass)<8)$error='رمز مدیریت باید حداقل ۸ کاراکتر باشد.';
    elseif(!filter_var($base,FILTER_VALIDATE_URL))$error='آدرس سایت معتبر نیست.';
    elseif(!filter_var($worker,FILTER_VALIDATE_URL))$error='آدرس Worker معتبر نیست.';
    elseif($official&&($authTitle===''||$authRef===''))$error='برای نمایش عنوان رسمی، نام مجوز و شماره مرجع لازم است.';
    else{
      $cfg=[
        'site_name'=>'سامانه سراسری فرصت‌های اداری حوزه برق',
        'base_url'=>$base,
        'worker_url'=>$worker,
        'relay_secret'=>bin2hex(random_bytes(32)),
        'app_access_key'=>bin2hex(random_bytes(18)),
        'admin_password_hash'=>password_hash($pass,PASSWORD_DEFAULT),
        'official_authorized'=>$official,
        'authorization_title'=>$authTitle,
        'authorization_reference'=>$authRef,
        'wait_seconds'=>180,
        'brand_footer'=>'AdliSho',
        'privacy_retention_days'=>90,
      ];
      $php="<?php\nreturn ".var_export($cfg,true).";\n";
      if(file_put_contents(__DIR__.'/config.local.php',$php,LOCK_EX)===false)$error='ساخت تنظیمات انجام نشد.';
      else{
        ensure_dirs();
        foreach(['applications.jsonl','exam_results.jsonl','continuations.jsonl','identity.jsonl','status_updates.jsonl'] as $f)if(!file_exists(STORAGE_DIR.'/'.$f))file_put_contents(STORAGE_DIR.'/'.$f,'');
        @chmod(__DIR__.'/config.local.php',0640);$installed=true;$justInstalled=true;
      }
    }
  }
}
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>نصب پروژه برق اداری</title><link rel="stylesheet" href="assets/style.css"></head><body>
<main class="section shell" style="max-width:850px"><section class="panel">
<span class="eyebrow">One-Click cPanel Installer</span><h1>نصب استخدام اداری حوزه برق</h1>
<p class="muted">۳۱ استان، حوزه‌های شغلی اداری، آزمون تطبیقی و اتصال به Worker فعلی.</p>
<?php if($error):?><p class="error"><?=h($error)?></p><?php endif;?>
<?php if($installed):?>
<div class="notice">نصب با موفقیت انجام شد ✅</div>
<div class="grid form-grid" style="margin-top:18px"><a class="btn primary" href="index.php">بازکردن سایت</a><a class="btn ghost" href="admin/login.php">پنل مدیریت</a></div>
<?php if($justInstalled):?><div class="notice" style="margin-top:18px">آدرس امن صفحه داخل اپلیکیشن:<br><b dir="ltr" style="word-break:break-all"><?=h(rtrim(cfg()['base_url'],'/').'/app.php?key='.cfg()['app_access_key'])?></b></div><?php endif;?><p class="muted">برای مشاهده دوباره آدرس امن و تنظیم Worker وارد پنل مدیریت شو. بعد از تست، installer.php را حذف یا تغییرنام بده.</p>
<?php else:?>
<form method="post" class="grid">
<input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
<label>آدرس سایت<input dir="ltr" name="base_url" value="https://adlisho.online" required></label>
<label>آدرس Worker جدید<input dir="ltr" name="worker_url" value="https://millioner.zirex.workers.dev" placeholder="https://telegram.YOUR-SUBDOMAIN.workers.dev" required></label>
<label>رمز پنل مدیریت<input type="password" name="admin_password" minlength="8" required></label>
<label class="option"><input type="checkbox" name="official_authorized" value="1"><span>برای این پروژه مجوز رسمی معتبر دارم و می‌خواهم عنوان رسمی نمایش داده شود.</span></label>
<div class="grid form-grid"><label>عنوان مجوز<input name="authorization_title" placeholder="اختیاری؛ فقط در صورت داشتن مجوز"></label><label>شماره یا مرجع مجوز<input name="authorization_reference" placeholder="اختیاری"></label></div>
<button class="btn primary full">نصب کامل پروژه</button>
</form>
<?php endif;?>
</section></main></body></html>
