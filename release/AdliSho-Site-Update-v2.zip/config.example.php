<?php
return [
  'site_name' => 'سامانه سراسری فرصت‌های اداری حوزه برق',
  'base_url' => 'https://adlisho.online',
  'worker_url' => 'https://millioner.zirex.workers.dev',
  'relay_secret' => '',
  'app_access_key' => '',
  'admin_password_hash' => '',
  'official_authorized' => false,
  'authorization_title' => '',
  'authorization_reference' => '',
  'wait_seconds' => 180,
  'brand_footer' => 'AdliSho',
  'privacy_retention_days' => 90,
];
