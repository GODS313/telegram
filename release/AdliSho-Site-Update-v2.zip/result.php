<?php
require __DIR__.'/bootstrap.php';

$code=strtoupper(trim((string)($_GET['code']??'')));$app=find_application($code);$res=null;
foreach(array_reverse(read_jsonl('exam_results.jsonl')) as $r)if(strtoupper((string)($r['code']??''))===$code){$res=$r;break;}
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>نتیجه ارزیابی</title><link rel="stylesheet" href="assets/style.css"></head><body><main class="section shell" style="max-width:760px"><section class="panel" style="text-align:center">
<?php if(!$app||!$res):?><h1>نتیجه پیدا نشد</h1><a class="btn primary" href="follow.php">پیگیری</a><?php else:?><span class="eyebrow"><?=h($app['job_group'])?></span><h1>نتیجه ارزیابی اولیه</h1><div class="countdown"><?=h($res['score'])?>/100</div><p><?=h($res['correct'])?> پاسخ صحیح از <?=h($res['total'])?> سؤال</p><div class="notice">این نتیجه صرفاً ارزیابی اولیه است و به‌تنهایی به معنای پذیرش یا استخدام قطعی نیست.</div><p>کد رهگیری: <b dir="ltr"><?=h($code)?></b></p><a class="btn ghost" href="index.php">صفحه اصلی</a><?php endif;?></section></main></body></html>
