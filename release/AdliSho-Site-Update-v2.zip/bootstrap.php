<?php
declare(strict_types=1);
define('ROOT_DIR', __DIR__);
define('STORAGE_DIR', ROOT_DIR.'/storage');
define('RESUME_DIR', ROOT_DIR.'/uploads/resumes');
define('IDENTITY_DIR', ROOT_DIR.'/uploads/identity');

if (session_status() !== PHP_SESSION_ACTIVE) {
  ini_set('session.use_strict_mode','1');
  ini_set('session.use_only_cookies','1');
  session_set_cookie_params([
    'httponly'=>true,
    'secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'samesite'=>'Lax',
    'path'=>'/'
  ]);
  session_start();
}

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: SAMEORIGIN');

function cfg(): array {
  static $cfg;
  if (is_array($cfg)) return $cfg;
  $base=require ROOT_DIR.'/config.example.php';
  $local=file_exists(ROOT_DIR.'/config.local.php') ? require ROOT_DIR.'/config.local.php' : [];
  return $cfg=array_replace($base,is_array($local)?$local:[]);
}
function h($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function json_response(array $d,int $s=200): never {
  http_response_code($s);
  header('Content-Type: application/json; charset=UTF-8');
  header('Cache-Control: no-store');
  echo json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}
function csrf_token(): string {
  if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(24));
  return $_SESSION['csrf'];
}
function verify_csrf(?string $t): bool {
  return is_string($t)&&isset($_SESSION['csrf'])&&hash_equals($_SESSION['csrf'],$t);
}
function ensure_dirs(): void {
  foreach([STORAGE_DIR,RESUME_DIR,IDENTITY_DIR] as $d) if(!is_dir($d)) @mkdir($d,0750,true);
}
function client_ip(): string {
  return $_SERVER['HTTP_CF_CONNECTING_IP']??$_SERVER['REMOTE_ADDR']??'';
}
function normalize_digits(string $s): string {
  return strtr($s,['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
}
function save_jsonl(string $f,array $r): bool {
  ensure_dirs();
  return file_put_contents(STORAGE_DIR.'/'.$f,json_encode($r,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL,FILE_APPEND|LOCK_EX)!==false;
}
function read_jsonl(string $f): array {
  $p=STORAGE_DIR.'/'.$f; if(!is_file($p))return[];
  $rows=[]; foreach(file($p,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES)?:[] as $l){$j=json_decode($l,true);if(is_array($j))$rows[]=$j;}
  return $rows;
}
function generate_code(): string {
  return 'KS-BR-'.date('ymd').'-'.strtoupper(substr(bin2hex(random_bytes(6)),0,8));
}
function find_application(string $code): ?array {
  foreach(array_reverse(read_jsonl('applications.jsonl')) as $r)
    if(strtoupper((string)($r['code']??''))===strtoupper($code))return$r;
  return null;
}
function post_json(string $url,array $payload): array {
  $body=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  return http_json('POST',$url,$body,['Content-Type: application/json; charset=UTF-8']);
}
function http_json(string $method,string $url,?string $body=null,array $headers=[]): array {
  if(function_exists('curl_init')){
    $ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>12,CURLOPT_CONNECTTIMEOUT=>6,CURLOPT_HTTPHEADER=>$headers]);
    if($body!==null)curl_setopt($ch,CURLOPT_POSTFIELDS,$body);
    $res=curl_exec($ch);$err=curl_error($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    $decoded=is_string($res)?json_decode($res,true):null;
    return['ok'=>$res!==false&&$status>=200&&$status<300,'status'=>$status,'body'=>$res,'json'=>is_array($decoded)?$decoded:null,'error'=>$err];
  }
  $options=['method'=>$method,'timeout'=>12,'ignore_errors'=>true,'header'=>implode("\r\n",$headers)."\r\n"];
  if($body!==null)$options['content']=$body;
  $ctx=stream_context_create(['http'=>$options]);
  $res=@file_get_contents($url,false,$ctx);
  $status=0;if(isset($http_response_header[0])&&preg_match('/\s(\d{3})\s/',$http_response_header[0],$m))$status=(int)$m[1];
  $decoded=is_string($res)?json_decode($res,true):null;
  return['ok'=>$res!==false&&$status>=200&&$status<300,'status'=>$status,'body'=>$res,'json'=>is_array($decoded)?$decoded:null,'error'=>$res===false?(error_get_last()['message']??'error'):''];
}
function worker_send(string $path,array $payload): array {
  $base=rtrim((string)(cfg()['worker_url']??''),'/');
  if($base==='')return['ok'=>false,'error'=>'worker_not_configured'];
  $secret=(string)(cfg()['relay_secret']??'');
  if(strlen($secret)<32)return['ok'=>false,'error'=>'relay_secret_not_configured'];
  $body=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  if(!is_string($body))return['ok'=>false,'error'=>'json_encode_failed'];
  $signature=hash_hmac('sha256',$body,$secret);
  return http_json('POST',$base.'/'.ltrim($path,'/'),$body,[
    'Content-Type: application/json; charset=UTF-8',
    'X-AdliSho-Signature: '.$signature,
    'User-Agent: AdliSho-cPanel/2.0',
  ]);
}
function worker_health(): array {
  $base=rtrim((string)(cfg()['worker_url']??''),'/');
  if($base==='')return['ok'=>false,'error'=>'worker_not_configured'];
  return http_json('GET',$base.'/health',null,['Accept: application/json','User-Agent: AdliSho-cPanel/2.0']);
}
function rate_limit(string $key,int $limit=5,int $window=600): bool {
  $now=time(); $_SESSION['rates'][$key]=array_values(array_filter($_SESSION['rates'][$key]??[],fn($t)=>$t>$now-$window));
  if(count($_SESSION['rates'][$key])>=$limit)return false;
  $_SESSION['rates'][$key][]=$now;return true;
}
function require_admin(): void {
  if(empty($_SESSION['admin_ok'])){header('Location: login.php');exit;}
}

function config_file_path(): string { return ROOT_DIR.'/config.local.php'; }
function save_config(array $config): bool {
  $php="<?php\nreturn ".var_export($config,true).";\n";
  $tmp=config_file_path().'.tmp';
  if(file_put_contents($tmp,$php,LOCK_EX)===false)return false;
  @chmod($tmp,0640);
  return @rename($tmp,config_file_path());
}
function file_rate_limit(string $bucket,string $identity,int $limit,int $window): bool {
  ensure_dirs();$path=STORAGE_DIR.'/rate_'.$bucket.'.json';$now=time();$key=hash('sha256',$identity);
  $fh=@fopen($path,'c+');if(!$fh)return true;
  if(!flock($fh,LOCK_EX)){fclose($fh);return true;}
  $raw=stream_get_contents($fh);$data=json_decode($raw?:'{}',true);if(!is_array($data))$data=[];
  foreach($data as $k=>$times){$data[$k]=array_values(array_filter(is_array($times)?$times:[],fn($t)=>(int)$t>$now-$window));if(!$data[$k])unset($data[$k]);}
  $allowed=count($data[$key]??[])<$limit;if($allowed)$data[$key][]=$now;
  ftruncate($fh,0);rewind($fh);fwrite($fh,json_encode($data));fflush($fh);flock($fh,LOCK_UN);fclose($fh);
  return $allowed;
}

function latest_record(string $file,string $code): ?array {
  foreach(array_reverse(read_jsonl($file)) as $row){
    if(strtoupper((string)($row['code']??''))===strtoupper($code)) return $row;
  }
  return null;
}
function has_record(string $file,string $code): bool {
  return latest_record($file,$code)!==null;
}
function app_access_granted(): bool {
  if(!empty($_SESSION['app_access_ok'])) return true;
  $expected=(string)(cfg()['app_access_key']??'');
  $provided=(string)($_GET['key']??$_POST['app_key']??'');
  if($expected!=='' && $provided!=='' && hash_equals($expected,$provided)){
    $_SESSION['app_access_ok']=true;
    return true;
  }
  return false;
}
function require_app_access(): void {
  if(!app_access_granted()){
    http_response_code(403);
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>دسترسی اپلیکیشن</title><body style="font-family:Tahoma;background:#06131b;color:#fff;padding:30px"><h2>این صفحه فقط برای داخل اپلیکیشن فعال است.</h2><p>آدرس امن صفحه را داخل WebView اپلیکیشن قرار دهید.</p></body></html>';
    exit;
  }
}

function application_status(string $code): string {
  $row=latest_record('status_updates.jsonl',$code);
  return (string)($row['status']??'registered');
}
function purge_application(string $code): bool {
  $code=strtoupper(trim($code));if($code==='')return false;ensure_dirs();
  $files=['applications.jsonl','continuations.jsonl','identity.jsonl','exam_results.jsonl','status_updates.jsonl'];
  foreach($files as $file){
    $rows=read_jsonl($file);$kept=[];
    foreach($rows as $row){
      if(strtoupper((string)($row['code']??''))===$code){
        if($file==='identity.jsonl')foreach(['selfie','video'] as $key){$name=basename((string)($row[$key]??''));if($name!=='')@unlink(IDENTITY_DIR.'/'.$name);}
        if($file==='applications.jsonl'){$resume=basename((string)($row['resume']??''));if($resume!=='')@unlink(RESUME_DIR.'/'.$resume);}
        continue;
      }
      $kept[]=$row;
    }
    $text='';foreach($kept as $row)$text.=json_encode($row,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
    if(file_put_contents(STORAGE_DIR.'/'.$file,$text,LOCK_EX)===false)return false;
  }
  return true;
}
function cleanup_expired_data(): int {
  $days=max(1,(int)(cfg()['privacy_retention_days']??90));$cutoff=time()-($days*86400);$count=0;
  foreach(read_jsonl('applications.jsonl') as $row){$created=strtotime((string)($row['created_at']??''));if($created!==false&&$created<$cutoff&&purge_application((string)($row['code']??'')))$count++;}
  return $count;
}

function official_label(): string {
  return !empty(cfg()['official_authorized']) ? 'سامانه مجاز جذب و ارزیابی' : 'سامانه مستقل پیش‌ثبت‌نام و ارزیابی اولیه';
}
