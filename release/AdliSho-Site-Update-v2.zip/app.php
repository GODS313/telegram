<?php
require __DIR__.'/bootstrap.php';
require_app_access();

$code=strtoupper(trim((string)($_GET['code']??'')));
$app=$code!==''?find_application($code):null;
$continuation=$app?latest_record('continuations.jsonl',$code):null;
$identity=$app?latest_record('identity.jsonl',$code):null;
$result=$app?latest_record('exam_results.jsonl',$code):null;
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><title>پرونده داخل اپلیکیشن</title><link rel="stylesheet" href="assets/style.css"><style>
.app-shell{max-width:900px}.app-head{position:sticky;top:0;z-index:5;background:rgba(6,19,27,.92);backdrop-filter:blur(14px);border-bottom:1px solid var(--line);padding:12px 0}.app-step{padding:20px}.app-step.done{border-color:rgba(117,229,179,.38)}.status-pill{display:inline-flex;padding:7px 11px;border-radius:999px;border:1px solid var(--line);color:var(--muted)}.status-pill.done{color:var(--green);border-color:rgba(117,229,179,.35)}.result-score{font-size:48px;color:var(--gold);font-weight:900}
</style></head><body>
<div class="app-head"><div class="shell app-shell topbar" style="padding:0"><div class="brand"><span class="brand-mark">⚡</span><span><b>پرونده استخدام</b><small>صفحه داخلی اپلیکیشن</small></span></div></div></div>
<main class="section shell app-shell">
<?php if(!$code):?>
<section class="panel"><span class="eyebrow">ورود به پرونده</span><h1>کد رهگیری را وارد کنید</h1><form method="get" class="grid"><label>کد رهگیری<input dir="ltr" name="code" required></label><button class="btn primary">نمایش پرونده</button></form></section>
<?php elseif(!$app):?>
<section class="panel"><h1>پرونده پیدا نشد</h1><p class="error">کد واردشده معتبر نیست.</p><a class="btn ghost" href="app.php">تلاش دوباره</a></section>
<?php else:?>
<section class="panel"><span class="eyebrow"><?=h($app['province'])?></span><h1><?=h($app['full_name'])?></h1><p class="muted"><?=h($app['job_group'])?> — <?=h($app['job_title'])?></p><div class="notice">کد رهگیری: <b dir="ltr"><?=h($code)?></b></div></section>

<section class="card app-step <?=$continuation?'done':''?>" style="margin-top:18px">
<div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><h3>۱. تکمیل اطلاعات استخدامی</h3><span class="status-pill <?=$continuation?'done':''?>"><?=$continuation?'تکمیل شد':'در انتظار'?></span></div>
<?php if(!$continuation):?>
<form id="continueForm" class="grid">
<input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="code" value="<?=h($code)?>">
<div class="grid form-grid"><label>وضعیت اشتغال<select name="employment_status" required><option value="">انتخاب کنید</option><option>جویای کار</option><option>شاغل</option><option>دانشجو</option></select></label><label>نوع همکاری ترجیحی<select name="employment_type" required><option value="">انتخاب کنید</option><option>تمام‌وقت</option><option>پاره‌وقت</option><option>قراردادی</option></select></label></div>
<div class="grid form-grid"><label>زمان آمادگی شروع<select name="availability" required><option value="">انتخاب کنید</option><option>فوری</option><option>تا یک ماه</option><option>بیش از یک ماه</option></select></label><label>مهارت نرم‌افزاری اصلی<input name="software_skill" required maxlength="120"></label></div>
<label>شرح تکمیلی سوابق و توانمندی‌ها<textarea name="additional_notes" required maxlength="1200"></textarea></label>
<button class="btn primary full">ثبت اطلاعات تکمیلی</button><p id="continueStatus"></p>
</form>
<?php else:?><p class="ok">اطلاعات تکمیلی پرونده ثبت شده است.</p><?php endif;?>
</section>

<section class="card app-step <?=$identity?'done':''?>" style="margin-top:18px">
<div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><h3>۲. احراز تصویری</h3><span class="status-pill <?=$identity?'done':''?>"><?=$identity?'دریافت شد':'در انتظار'?></span></div>
<?php if(!$identity):?>
<form id="identityForm" class="grid" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="code" value="<?=h($code)?>">
<label>تصویر سلفی<input type="file" name="selfie" accept="image/jpeg,image/png" capture="user" required></label>
<label>ویدیوی کوتاه احراز — حداکثر ۱۵ مگابایت<input type="file" name="video" accept="video/mp4,video/webm,video/quicktime" capture="user" required></label>
<label class="option"><input type="checkbox" name="media_consent" value="1" required><span>با ثبت تصویر و ویدیو برای بررسی هویت پرونده موافقم.</span></label>
<p class="muted">این مرحله بررسی دستی است. دوربین و انتخاب فایل باید در WebView اپلیکیشن فعال باشد.</p>
<button class="btn primary full">ارسال تصویر و ویدیو</button><p id="identityStatus"></p>
</form>
<?php else:?><p class="ok">تصویر و ویدیوی احراز برای بررسی دریافت شده است.</p><?php endif;?>
</section>

<section class="card app-step <?=($continuation&&$identity)?'done':''?>" style="margin-top:18px">
<div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><h3>۳. آزمون استخدامی</h3><span class="status-pill"><?= $result?'نتیجه ثبت شد':(($continuation&&$identity)?'آماده':'قفل') ?></span></div>
<?php if($result):?><div class="result-score"><?=h($result['score'])?>/100</div><p><?=h($result['correct'])?> پاسخ صحیح از <?=h($result['total'])?> سؤال</p>
<?php elseif($continuation&&$identity):?><a class="btn primary full" href="exam.php?code=<?=rawurlencode($code)?>">شروع آزمون</a>
<?php else:?><p class="muted">پس از تکمیل اطلاعات و احراز تصویری، آزمون فعال می‌شود.</p><?php endif;?>
</section>
<?php endif;?>
</main>
<script>
async function sendForm(form,url,statusId){const status=document.querySelector(statusId),btn=form.querySelector('button');btn.disabled=true;status.textContent='در حال ارسال...';status.className='muted';try{const r=await fetch(url,{method:'POST',body:new FormData(form),headers:{'X-Requested-With':'fetch'}});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.message||'عملیات انجام نشد');status.className='ok';status.textContent='ثبت شد؛ در حال به‌روزرسانی...';setTimeout(()=>location.reload(),900)}catch(e){status.className='error';status.textContent=e.message;btn.disabled=false}}
const cf=document.querySelector('#continueForm');if(cf)cf.addEventListener('submit',e=>{e.preventDefault();sendForm(cf,'api/continue.php','#continueStatus')});
const idf=document.querySelector('#identityForm');if(idf)idf.addEventListener('submit',e=>{e.preventDefault();sendForm(idf,'api/identity.php','#identityStatus')});
</script></body></html>
