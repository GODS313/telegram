<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';

$file=__DIR__.'/downloads/app.apk';
if(!is_file($file)){
  http_response_code(404);
  exit('فایل اپلیکیشن پیدا نشد.');
}

save_jsonl('downloads.jsonl',[
  'created_at'=>date(DATE_ATOM),
  'ip_hash'=>hash('sha256',client_ip()),
  'user_agent_hash'=>hash('sha256',(string)($_SERVER['HTTP_USER_AGENT']??''))
]);

header('Content-Type: application/vnd.android.package-archive');
header('Content-Disposition: attachment; filename="AdliSho-Bargh.apk"');
header('Content-Length: '.filesize($file));
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
readfile($file);
