<?php
header('Location: index.php#registration', true, 302);
exit;
