<?php header('Location: follow.php', true, 302); exit;
