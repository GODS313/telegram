<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';require_admin();
if($_SERVER['REQUEST_METHOD']!=='POST'||!verify_csrf($_POST['csrf']??null)){http_response_code(419);exit('نشست منقضی شده است.');}
$code=strtoupper(trim((string)($_POST['code']??'')));$app=find_application($code);if(!$app){http_response_code(404);exit('پرونده پیدا نشد.');}
$action=(string)($_POST['action']??'');
if($action==='delete'){
  if((string)($_POST['confirm']??'')!==$code){header('Location: detail.php?code='.rawurlencode($code).'&error=confirm');exit;}
  if(!purge_application($code)){header('Location: detail.php?code='.rawurlencode($code).'&error=delete');exit;}
  header('Location: index.php?deleted=1');exit;
}
$allowed=['review','approved','rejected'];if(!in_array($action,$allowed,true)){http_response_code(422);exit('عملیات نامعتبر');}
save_jsonl('status_updates.jsonl',['code'=>$code,'created_at'=>date(DATE_ATOM),'status'=>$action]);
header('Location: detail.php?code='.rawurlencode($code).'&saved=1');exit;
