<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';require_admin();$message='';$kind='ok';
function uploaded_ok(string $field): bool { return isset($_FILES[$field])&&($_FILES[$field]['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_OK; }
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!verify_csrf($_POST['csrf']??null)){$message='نشست منقضی شده است.';$kind='error';}
  else{
    $action=(string)($_POST['action']??'');
    if($action==='apk'&&uploaded_ok('apk')){
      $tmp=$_FILES['apk']['tmp_name'];$size=(int)$_FILES['apk']['size'];$head=file_get_contents($tmp,false,null,0,2);
      if($size<1024||$size>100*1024*1024||$head!=="PK"){$message='فایل APK معتبر نیست یا بیش از ۱۰۰ مگابایت است.';$kind='error';}
      elseif(move_uploaded_file($tmp,dirname(__DIR__).'/downloads/app.apk')){file_put_contents(dirname(__DIR__).'/APK_SHA256.txt',hash_file('sha256',dirname(__DIR__).'/downloads/app.apk').PHP_EOL,LOCK_EX);$message='فایل APK و هش آن به‌روزرسانی شد.';}else{$message='ذخیره APK ناموفق بود.';$kind='error';}
    }elseif(in_array($action,['logo','banner'],true)&&uploaded_ok('image')){
      $tmp=$_FILES['image']['tmp_name'];$size=(int)$_FILES['image']['size'];$mime=(new finfo(FILEINFO_MIME_TYPE))->file($tmp);$target=$action==='logo'?'bargh-app-logo.webp':'bargh-final-banner.webp';
      if($mime!=='image/webp'||$size>5*1024*1024){$message='تصویر باید WebP و حداکثر ۵ مگابایت باشد.';$kind='error';}
      elseif(move_uploaded_file($tmp,dirname(__DIR__).'/assets/img/'.$target)){$message='تصویر با موفقیت جایگزین شد.';}else{$message='ذخیره تصویر ناموفق بود.';$kind='error';}
    }else{$message='فایل معتبر انتخاب نشده است.';$kind='error';}
  }
}
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>فایل‌ها و تصاویر</title><link rel="stylesheet" href="../assets/style.css"></head><body><main class="section shell" style="max-width:850px"><div class="topbar"><h1>فایل‌ها و تصاویر</h1><a class="btn ghost" href="index.php">بازگشت</a></div><?php if($message):?><p class="<?=$kind?>"><?=h($message)?></p><?php endif;?>
<section class="panel"><h2>فایل APK</h2><p class="muted">نسخه فعلی: <?=is_file(dirname(__DIR__).'/downloads/app.apk')?number_format(filesize(dirname(__DIR__).'/downloads/app.apk')/1024/1024,2).' MB':'وجود ندارد'?></p><form method="post" enctype="multipart/form-data" class="grid"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="apk"><input type="file" name="apk" accept=".apk,application/vnd.android.package-archive" required><button class="btn primary">جایگزینی APK</button></form></section>
<section class="panel" style="margin-top:16px"><h2>لوگوی اپلیکیشن</h2><img src="../assets/img/bargh-app-logo.webp" alt="لوگو" style="max-width:180px;border-radius:20px"><form method="post" enctype="multipart/form-data" class="grid"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="logo"><input type="file" name="image" accept="image/webp" required><button class="btn ghost">جایگزینی لوگو</button></form></section>
<section class="panel" style="margin-top:16px"><h2>بنر اصلی</h2><img src="../assets/img/bargh-final-banner.webp" alt="بنر" style="border-radius:20px"><form method="post" enctype="multipart/form-data" class="grid"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="banner"><input type="file" name="image" accept="image/webp" required><button class="btn ghost">جایگزینی بنر</button></form></section>
</main></body></html>
