<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';require_admin();
$file=basename((string)($_GET['file']??''));
if($file===''||!preg_match('/^[a-f0-9]{32}\.(jpg|png|mp4|webm|mov)$/',$file)){http_response_code(400);exit('نامعتبر');}
$allowed=false;foreach(read_jsonl('identity.jsonl') as $r){if(($r['selfie']??'')===$file||($r['video']??'')===$file){$allowed=true;break;}}
if(!$allowed){http_response_code(404);exit('یافت نشد');}
$path=IDENTITY_DIR.'/'.$file;if(!is_file($path)){http_response_code(404);exit('یافت نشد');}
$mime=(new finfo(FILEINFO_MIME_TYPE))->file($path);header('Content-Type: '.$mime);header('Content-Length: '.filesize($path));header('Content-Disposition: inline; filename="'.$file.'"');header('Cache-Control: private, no-store');readfile($path);
