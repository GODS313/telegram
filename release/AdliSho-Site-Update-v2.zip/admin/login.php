<?php
require dirname(__DIR__).'/bootstrap.php';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf($_POST['csrf']??null))$error='نشست منقضی شده است.';
 elseif(!file_rate_limit('admin_login',client_ip(),7,900))$error='تلاش‌های ناموفق زیاد است؛ ۱۵ دقیقه بعد دوباره امتحان کنید.';
 elseif(password_verify((string)($_POST['password']??''),(string)(cfg()['admin_password_hash']??''))){session_regenerate_id(true);$_SESSION['admin_ok']=true;header('Location:index.php');exit;}
 else $error='رمز نادرست است.';
}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ورود مدیریت</title><link rel="stylesheet" href="../assets/style.css"></head><body><main class="section shell" style="max-width:520px"><section class="panel"><h1>ورود مدیریت</h1><?php if($error):?><p class="error"><?=h($error)?></p><?php endif;?><form method="post" class="grid"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label>رمز مدیریت<input type="password" name="password" required></label><button class="btn primary">ورود</button></form></section></main></body></html>
