<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';require_admin();
header('Location: settings.php');exit;
