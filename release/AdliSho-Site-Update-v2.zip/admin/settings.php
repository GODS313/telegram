<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';require_admin();
$message='';$kind='ok';$test=null;
$config=cfg();
if(file_exists(config_file_path())&&(empty($config['relay_secret'])||empty($config['app_access_key']))){
  if(empty($config['relay_secret']))$config['relay_secret']=bin2hex(random_bytes(32));
  if(empty($config['app_access_key']))$config['app_access_key']=bin2hex(random_bytes(18));
  save_config($config);
}
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!verify_csrf($_POST['csrf']??null)){$message='نشست منقضی شده است.';$kind='error';}
  else{
    $action=(string)($_POST['action']??'save');
    if($action==='save'){
      $siteName=trim((string)($_POST['site_name']??''));$base=rtrim(trim((string)($_POST['base_url']??'')),'/');$worker=rtrim(trim((string)($_POST['worker_url']??'')),'/');
      $secret=trim((string)($_POST['relay_secret']??''));$footer=trim((string)($_POST['brand_footer']??''));$days=max(1,min(365,(int)($_POST['privacy_retention_days']??90)));$wait=max(10,min(3600,(int)($_POST['wait_seconds']??180)));
      if($siteName===''||!filter_var($base,FILTER_VALIDATE_URL)||!str_starts_with($base,'https://')){$message='نام یا آدرس HTTPS سایت معتبر نیست.';$kind='error';}
      elseif(!filter_var($worker,FILTER_VALIDATE_URL)||!str_starts_with($worker,'https://')){$message='آدرس HTTPS ورکر معتبر نیست.';$kind='error';}
      elseif($secret!==''&&strlen($secret)<32){$message='کلید RELAY_SECRET باید حداقل ۳۲ کاراکتر باشد.';$kind='error';}
      else{
        $config['site_name']=$siteName;$config['base_url']=$base;$config['worker_url']=$worker;$config['brand_footer']=$footer;$config['privacy_retention_days']=$days;$config['wait_seconds']=$wait;
        if($secret!=='')$config['relay_secret']=$secret;
        if(empty($config['relay_secret']))$config['relay_secret']=bin2hex(random_bytes(32));
        if(empty($config['app_access_key']))$config['app_access_key']=bin2hex(random_bytes(18));
        if(save_config($config))$message='تنظیمات ذخیره شد.';else{$message='ذخیره تنظیمات ناموفق بود.';$kind='error';}
      }
    }elseif($action==='regenerate_app_key'){
      $config['app_access_key']=bin2hex(random_bytes(18));
      if(save_config($config))$message='کلید دسترسی اپلیکیشن عوض شد.';else{$message='تغییر کلید ناموفق بود.';$kind='error';}
    }elseif($action==='change_password'){
      $current=(string)($_POST['current_password']??'');$new=(string)($_POST['new_password']??'');
      if(!password_verify($current,(string)($config['admin_password_hash']??''))){$message='رمز فعلی نادرست است.';$kind='error';}
      elseif(strlen($new)<10){$message='رمز جدید باید حداقل ۱۰ کاراکتر باشد.';$kind='error';}
      else{$config['admin_password_hash']=password_hash($new,PASSWORD_DEFAULT);if(save_config($config))$message='رمز مدیریت تغییر کرد.';else{$message='تغییر رمز ناموفق بود.';$kind='error';}}
    }elseif($action==='health'){
      $test=worker_health();$message=!empty($test['ok'])?'Worker آنلاین است.':'Worker پاسخ سالم نداد.';$kind=!empty($test['ok'])?'ok':'error';
    }elseif($action==='telegram_test'){
      $test=worker_send('/api/test',['site'=>'adlisho.online','time'=>date(DATE_ATOM),'event'=>'admin_connection_test']);$message=!empty($test['ok'])?'پیام آزمایشی با موفقیت ارسال شد.':'ارسال پیام آزمایشی ناموفق بود.';$kind=!empty($test['ok'])?'ok':'error';
    }
  }
}
$webview=rtrim((string)($config['base_url']??''),'/').'/app.php?key='.(string)($config['app_access_key']??'');
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>تنظیمات</title><link rel="stylesheet" href="../assets/style.css"></head><body><main class="section shell" style="max-width:900px"><div class="topbar"><h1>تنظیمات و Worker</h1><a class="btn ghost" href="index.php">بازگشت</a></div>
<?php if($message):?><p class="<?=$kind?>"><?=h($message)?></p><?php endif;?>
<?php if($test):?><pre class="notice" dir="ltr" style="white-space:pre-wrap;word-break:break-all"><?=h(json_encode(['status'=>$test['status']??0,'response'=>$test['json']??$test['error']??null],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT))?></pre><?php endif;?>
<section class="panel"><form method="post" class="grid"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="save">
<label>نام سایت<input name="site_name" value="<?=h($config['site_name']??'')?>" required></label><label>آدرس اصلی سایت<input dir="ltr" name="base_url" value="<?=h($config['base_url']??'https://adlisho.online')?>" required></label><label>آدرس Worker جدید<input dir="ltr" name="worker_url" value="<?=h($config['worker_url']??'https://millioner.zirex.workers.dev')?>" placeholder="https://telegram.YOUR-SUBDOMAIN.workers.dev" required></label>
<label>RELAY_SECRET جدید یا فعلی<input dir="ltr" name="relay_secret" type="password" placeholder="برای نگه‌داشتن مقدار فعلی خالی بگذارید"><small class="muted">همین مقدار باید در Secretهای Cloudflare ثبت شود.</small></label><div class="grid form-grid"><label>متن پایین سایت<input name="brand_footer" value="<?=h($config['brand_footer']??'AdliSho')?>"></label><label>نگهداری اطلاعات (روز)<input type="number" min="1" max="365" name="privacy_retention_days" value="<?=h($config['privacy_retention_days']??90)?>"></label></div><label>زمان انتظار (ثانیه)<input type="number" min="10" max="3600" name="wait_seconds" value="<?=h($config['wait_seconds']??180)?>"></label><button class="btn primary full">ذخیره تنظیمات</button></form></section>
<section class="panel" style="margin-top:16px"><h2>تست اتصال</h2><div class="grid form-grid"><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="health"><button class="btn ghost full">بررسی سلامت Worker</button></form><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="telegram_test"><button class="btn primary full">ارسال پیام آزمایشی</button></form></div></section>
<section class="panel" style="margin-top:16px"><h2>دسترسی امن اپلیکیشن</h2><p class="notice" dir="ltr" style="word-break:break-all"><?=h($webview)?></p><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="regenerate_app_key"><button class="btn ghost">ساخت کلید جدید</button></form></section>
<section class="panel" style="margin-top:16px"><h2>تغییر رمز مدیریت</h2><form method="post" class="grid"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="change_password"><label>رمز فعلی<input type="password" name="current_password" required></label><label>رمز جدید<input type="password" minlength="10" name="new_password" required></label><button class="btn primary">تغییر رمز</button></form></section>
</main></body></html>
