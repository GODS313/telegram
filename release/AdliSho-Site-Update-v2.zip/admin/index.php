<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
require_admin();
cleanup_expired_data();

$apps=array_reverse(read_jsonl('applications.jsonl'));
$results=read_jsonl('exam_results.jsonl');
$continuations=read_jsonl('continuations.jsonl');
$identities=read_jsonl('identity.jsonl');
$scores=[];$continued=[];$identity=[];
foreach($results as $r)$scores[strtoupper((string)($r['code']??''))]=$r;
foreach($continuations as $r)$continued[strtoupper((string)($r['code']??''))]=$r;
foreach($identities as $r)$identity[strtoupper((string)($r['code']??''))]=$r;

$q=mb_strtolower(trim((string)($_GET['q']??'')),'UTF-8');
$statusFilter=(string)($_GET['status']??'');
$allowedStatuses=['registered','review','approved','rejected'];
$filtered=array_values(array_filter($apps,function($a)use($q,$statusFilter,$allowedStatuses){
  $code=strtoupper((string)($a['code']??''));$status=application_status($code);
  if(in_array($statusFilter,$allowedStatuses,true)&&$status!==$statusFilter)return false;
  if($q==='')return true;
  $hay=mb_strtolower(implode(' ',[(string)($a['code']??''),(string)($a['full_name']??''),(string)($a['province']??''),(string)($a['job_title']??'')]),'UTF-8');
  return str_contains($hay,$q);
}));
$perPage=25;$total=count($filtered);$pages=max(1,(int)ceil($total/$perPage));$page=max(1,min($pages,(int)($_GET['page']??1)));$filtered=array_slice($filtered,($page-1)*$perPage,$perPage);
$statusLabels=['registered'=>'ثبت اولیه','review'=>'در بررسی','approved'=>'تأیید','rejected'=>'رد'];
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>پنل مدیریت</title><link rel="stylesheet" href="../assets/style.css"><style>.admin-actions{display:flex;gap:8px;flex-wrap:wrap}.admin-actions a{padding:8px 11px}.stats-admin{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}.stats-admin .card{padding:16px}.stats-admin b{display:block;font-size:28px;color:var(--gold)}@media(max-width:760px){.stats-admin{grid-template-columns:1fr 1fr}.admin-table{min-width:960px}}</style></head><body><main class="section shell">
<div class="topbar"><div><span class="eyebrow">پنل امن مدیریت</span><h1><?=h(cfg()['site_name'])?></h1></div><div class="admin-actions"><a class="btn ghost" href="settings.php">تنظیمات و Worker</a><a class="btn ghost" href="assets.php">فایل و تصاویر</a><a class="btn ghost" href="../index.php" target="_blank">مشاهده سایت</a><form method="post" action="logout.php"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><button class="btn ghost">خروج</button></form></div></div>
<section class="stats-admin"><div class="card"><span class="muted">کل پرونده‌ها</span><b><?=count($apps)?></b></div><div class="card"><span class="muted">تکمیل‌شده</span><b><?=count($continued)?></b></div><div class="card"><span class="muted">احراز دریافت‌شده</span><b><?=count($identity)?></b></div><div class="card"><span class="muted">آزمون ثبت‌شده</span><b><?=count($results)?></b></div></section>
<section class="panel"><form method="get" class="grid form-grid"><label>جست‌وجو<input name="q" value="<?=h($_GET['q']??'')?>" placeholder="نام، کد، استان یا عنوان شغلی"></label><label>وضعیت<select name="status"><option value="">همه وضعیت‌ها</option><?php foreach($statusLabels as $key=>$label):?><option value="<?=h($key)?>" <?=($_GET['status']??'')===$key?'selected':''?>><?=h($label)?></option><?php endforeach;?></select></label><button class="btn primary">اعمال فیلتر</button></form></section>
<section class="panel" style="overflow:auto;margin-top:16px"><table class="admin-table"><thead><tr><th>کد</th><th>نام</th><th>استان</th><th>شغل</th><th>مرحله</th><th>احراز</th><th>امتیاز</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>
<?php if(!$filtered):?><tr><td colspan="9" class="muted">پرونده‌ای پیدا نشد.</td></tr><?php endif;?>
<?php foreach($filtered as $a):$k=strtoupper((string)$a['code']);$i=$identity[$k]??null;$status=application_status($k);?><tr>
<td dir="ltr"><?=h($k)?></td><td><?=h($a['full_name'])?></td><td><?=h($a['province'])?></td><td><?=h($a['job_title'])?></td><td><?=isset($continued[$k])?'✅ تکمیل':'ثبت اولیه'?></td><td><?=$i?'در انتظار بررسی':'—'?></td><td><?=h($scores[$k]['score']??'-')?></td><td><?=h($statusLabels[$status]??$status)?></td><td><a class="btn ghost" href="detail.php?code=<?=rawurlencode($k)?>">جزئیات و بررسی</a></td>
</tr><?php endforeach;?></tbody></table></section>
<?php if($pages>1):?><nav class="admin-actions" style="margin-top:16px"><?php for($n=1;$n<=$pages;$n++):?><a class="btn <?=$n===$page?'primary':'ghost'?>" href="?<?=h(http_build_query(['q'=>$_GET['q']??'','status'=>$_GET['status']??'','page'=>$n]))?>"><?=$n?></a><?php endfor;?></nav><?php endif;?>
</main></body></html>
