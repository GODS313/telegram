<?php
require __DIR__.'/bootstrap.php';
$data=require __DIR__.'/data.php';
$jobs=$data['jobs'];$provinces=$data['provinces'];

$jobVisuals=[
  'اداری و دبیرخانه'=>[
    'image'=>'admin-office.svg',
    'title'=>'مدیریت مکاتبات، اسناد و جریان اداری',
    'description'=>'مناسب افراد دقیق، منظم و مسلط به مکاتبات رسمی، ثبت و گردش نامه، بایگانی، صورت‌جلسه و هماهنگی دفتر.'
  ],
  'مالی و حسابداری'=>[
    'image'=>'finance.svg',
    'title'=>'امور مالی، بودجه و حسابداری سازمانی',
    'description'=>'برای متقاضیان مسلط به ثبت اسناد، کنترل داخلی، بودجه، حقوق و دستمزد، گزارش‌های مالی و کار با نرم‌افزارهای حسابداری.'
  ],
  'منابع انسانی'=>[
    'image'=>'hr.svg',
    'title'=>'جذب، آموزش و توسعه سرمایه انسانی',
    'description'=>'شامل جذب و استخدام، آموزش کارکنان، ارزیابی عملکرد، امور پرسنلی و پشتیبانی فرایندهای منابع انسانی.'
  ],
  'فناوری اطلاعات'=>[
    'image'=>'it.svg',
    'title'=>'پشتیبانی سیستم‌ها، شبکه و داده',
    'description'=>'مناسب کارشناسان فناوری اطلاعات، پشتیبانی کاربران، شبکه، امنیت پایه، تحلیل داده و نگهداری سامانه‌های سازمانی.'
  ],
  'خدمات مشترکین'=>[
    'image'=>'customer.svg',
    'title'=>'پاسخگویی، پیگیری و خدمات مشترکین',
    'description'=>'برای افراد دارای مهارت ارتباطی، صبر، پاسخگویی حرفه‌ای، ثبت درخواست، مرکز تماس و پیگیری امور مشترکین.'
  ],
  'حقوقی و قراردادها'=>[
    'image'=>'legal.svg',
    'title'=>'قراردادها، مناقصات و امور حقوقی',
    'description'=>'شامل بررسی قراردادها، مناقصات، دعاوی، مستندسازی حقوقی، پیگیری تعهدات و کنترل اسناد قانونی.'
  ],
  'تدارکات و پشتیبانی'=>[
    'image'=>'supply.svg',
    'title'=>'خرید، انبار و پشتیبانی عملیاتی',
    'description'=>'برای کارشناسان خرید، کارپردازی، کنترل موجودی، انبار، تأمین کالا و پشتیبانی واحدهای سازمانی.'
  ],
  'برنامه‌ریزی و آمار'=>[
    'image'=>'planning.svg',
    'title'=>'برنامه‌ریزی، تحلیل و کنترل عملکرد',
    'description'=>'مناسب افراد مسلط به تحلیل داده، شاخص‌های عملکرد، گزارش مدیریتی، کنترل پروژه، آمار و برنامه‌ریزی سازمانی.'
  ],
  'روابط عمومی'=>[
    'image'=>'pr.svg',
    'title'=>'ارتباطات سازمانی و رسانه',
    'description'=>'شامل تولید محتوا، اطلاع‌رسانی، ارتباط با رسانه، مدیریت رویداد، ارتباطات داخلی و پاسخگویی سازمانی.'
  ]
];

$apkHash=is_file(__DIR__.'/APK_SHA256.txt')?trim((string)file_get_contents(__DIR__.'/APK_SHA256.txt')):'';
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#06131b">
<title><?=h(cfg()['site_name'])?></title>
<link rel="stylesheet" href="assets/style.css?v=20260714">
</head>
<body>

<header class="shell topbar">
  <a class="brand" href="index.php">
    <span class="brand-mark">⚡</span>
    <span><b>فرصت‌های اداری حوزه برق</b><small><?=h(official_label())?></small></span>
  </a>
  <div class="top-actions">
    <a class="btn ghost" href="#jobs">فرصت‌های شغلی</a>
    <a class="btn primary" href="#registration">ثبت‌نام اولیه</a>
  </div>
</header>

<main>
<section class="hero hero-poster-section">
  <div class="shell">
    <figure class="campaign-banner">
      <img src="assets/img/bargh-final-banner.webp" alt="بنر استخدام اداری حوزه برق، آزمون تخصصی و پوشش ۳۱ استان">
    </figure>
    <div class="hero-actions">
      <a class="btn primary" href="#registration">شروع ثبت‌نام اولیه</a>
      <a class="btn ghost" href="#download-app">دانلود اپلیکیشن</a>
    </div>
  </div>
</section>

<section class="section" id="registration">
<div class="shell registration-shell">
<section class="panel registration-panel">
  <div class="section-heading">
    <span class="eyebrow">مرحله اول</span>
    <h2>ثبت‌نام اولیه</h2>
    <p class="muted">اطلاعات اولیه را ثبت کنید و کد رهگیری بگیرید. ادامه ثبت‌نام، بارگذاری مدارک، احراز تصویری و آزمون تخصصی داخل اپلیکیشن انجام می‌شود.</p>
  </div>

  <form id="applyForm" class="grid">
    <input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
    <input type="hidden" name="birth_date" id="birthDateValue">

    <div class="grid form-grid">
      <label>نام و نام خانوادگی
        <input name="full_name" required maxlength="80" autocomplete="name">
      </label>
      <label>شماره موبایل
        <input name="phone" required inputmode="tel" maxlength="16" autocomplete="tel">
      </label>
    </div>

    <div class="grid form-grid">
      <label>کد ملی
        <input name="national_id" required inputmode="numeric" minlength="10" maxlength="10">
      </label>

      <fieldset class="jalali-fieldset">
        <legend>تاریخ تولد شمسی</legend>
        <div class="jalali-date-grid">
          <select id="birthDay" required aria-label="روز تولد">
            <option value="">روز</option>
            <?php for($d=1;$d<=31;$d++):?><option value="<?=str_pad((string)$d,2,'0',STR_PAD_LEFT)?>"><?=$d?></option><?php endfor;?>
          </select>

          <select id="birthMonth" required aria-label="ماه تولد">
            <option value="">ماه</option>
            <option value="01">فروردین</option><option value="02">اردیبهشت</option>
            <option value="03">خرداد</option><option value="04">تیر</option>
            <option value="05">مرداد</option><option value="06">شهریور</option>
            <option value="07">مهر</option><option value="08">آبان</option>
            <option value="09">آذر</option><option value="10">دی</option>
            <option value="11">بهمن</option><option value="12">اسفند</option>
          </select>

          <select id="birthYear" required aria-label="سال تولد">
            <option value="">سال</option>
            <?php for($y=1387;$y>=1320;$y--):?><option value="<?=$y?>"><?=$y?></option><?php endfor;?>
          </select>
        </div>
        <small>تاریخ به‌صورت شمسی ثبت می‌شود؛ حداقل سن ثبت‌نام ۱۸ سال است.</small>
      </fieldset>
    </div>

    <div class="grid form-grid">
      <label>استان
        <select name="province" required>
          <option value="">انتخاب استان</option>
          <?php foreach($provinces as $p):?><option><?=h($p)?></option><?php endforeach;?>
        </select>
      </label>
      <label>شهر
        <input name="city" required maxlength="50">
      </label>
    </div>

    <div class="grid form-grid">
      <label>مدرک تحصیلی
        <select name="education" required>
          <option value="">انتخاب کنید</option>
          <option>دیپلم</option><option>کاردانی</option><option>کارشناسی</option>
          <option>کارشناسی ارشد</option><option>دکتری</option>
        </select>
      </label>
      <label>رشته تحصیلی
        <input name="field" required maxlength="100">
      </label>
    </div>

    <div class="grid form-grid">
      <label>گروه شغلی
        <select name="job_group" id="jobGroup" required>
          <option value="">انتخاب گروه</option>
          <?php foreach($jobs as $g=>$ts):?><option value="<?=h($g)?>"><?=h($g)?></option><?php endforeach;?>
        </select>
      </label>
      <label>عنوان شغلی
        <select name="job_title" id="jobTitle" required>
          <option value="">ابتدا گروه را انتخاب کنید</option>
        </select>
      </label>
    </div>

    <label class="option consent-option">
      <input type="checkbox" name="consent" value="1" required>
      <span>با ثبت و بررسی اطلاعات برای ارزیابی اولیه موافقم و می‌دانم ثبت درخواست تضمین استخدام نیست.</span>
    </label>

    <button class="btn primary full form-submit">ثبت اولیه و دریافت کد رهگیری</button>
    <div id="successBox" class="notice" hidden></div>
    <p id="status" aria-live="polite"></p>
  </form>
</section>
</div>
</section>

<section class="section" id="jobs">
<div class="shell">
  <div class="section-heading">
    <span class="eyebrow">زمینه‌های اداری</span>
    <h2>گروه‌های شغلی و توضیحات کامل</h2>
    <p class="muted">روی هر گروه بزنید تا عنوان‌های شغلی و شرح آن بخش باز شود.</p>
  </div>

  <div class="jobs jobs-accordion">
    <?php foreach($jobs as $group=>$titles):
      $visual=$jobVisuals[$group]??['image'=>'admin-office.svg','title'=>$group,'description'=>'شرح این گروه شغلی'];
    ?>
    <details class="card job-card job-detail">
      <summary>
        <img src="assets/img/<?=h($visual['image'])?>" alt="<?=h($group)?>">
        <div class="job-summary-text">
          <span class="tag"><?=h($group)?></span>
          <h3><?=h($visual['title'])?></h3>
          <span class="open-hint">نمایش توضیحات و موقعیت‌ها</span>
        </div>
        <span class="details-arrow">⌄</span>
      </summary>
      <div class="job-expanded">
        <p><?=h($visual['description'])?></p>
        <div class="job-titles">
          <?php foreach($titles as $title):?><span><?=h($title)?></span><?php endforeach;?>
        </div>
        <a class="btn ghost" href="#registration" data-job-group="<?=h($group)?>">انتخاب این گروه</a>
      </div>
    </details>
    <?php endforeach;?>
  </div>
</div>
</section>

<section class="section app-download-section" id="download-app">
<div class="shell">
  <section class="app-download-card">
    <div class="app-identity">
      <img class="app-logo-image" src="assets/img/bargh-app-logo.webp" alt="لوگوی اپلیکیشن استخدام اداری حوزه برق">
      <div>
        <span class="eyebrow">ادامه مراحل فقط داخل اپلیکیشن</span>
        <h2>اپلیکیشن استخدام اداری حوزه برق</h2>
        <p class="muted">پیگیری پرونده، تکمیل اطلاعات، ارسال تصویر و ویدیو، شرکت در آزمون تخصصی و مشاهده نتیجه داخل اپلیکیشن انجام می‌شود.</p>
        <div class="trust-badges">
          <span>🔐 دریافت مستقیم از دامنه پروژه</span>
          <span>✅ کد رهگیری اختصاصی</span>
          <span>📝 آزمون تخصصی متناسب با شغل</span>
        </div>
        <a class="btn primary app-download-button" href="download.php">دانلود مستقیم فایل APK</a>
        <?php if($apkHash!==''):?><small class="hash-note">شناسه فایل: <?=h(substr($apkHash,0,16))?>…</small><?php endif;?>
      </div>
    </div>

    <div class="qr-panel">
      <img src="assets/img/app-download-qr.png" alt="QR دانلود اپلیکیشن">
      <b>اسکن برای دانلود</b>
      <span>adlisho.online</span>
    </div>
  </section>
</div>
</section>

<section class="section">
<div class="shell">
  <div class="section-heading">
    <span class="eyebrow">پوشش کشوری</span>
    <h2>۳۱ استان ایران</h2>
  </div>
  <div class="province-grid"><?php foreach($provinces as $p):?><div class="province"><?=h($p)?></div><?php endforeach;?></div>
</div>
</section>
</main>

<footer class="footer">
<div class="shell">ثبت اولیه در سایت انجام می‌شود؛ ادامه پرونده و آزمون تخصصی داخل اپلیکیشن است. — <?=h(cfg()['brand_footer'])?></div>
</footer>

<script>
const jobs=<?=json_encode($jobs,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)?>;
const group=document.querySelector('#jobGroup');
const title=document.querySelector('#jobTitle');

function updateTitles(){
  title.innerHTML='<option value="">انتخاب عنوان شغلی</option>';
  (jobs[group.value]||[]).forEach(value=>{
    const option=document.createElement('option');
    option.value=value;
    option.textContent=value;
    title.appendChild(option);
  });
}

group.addEventListener('change',updateTitles);

document.querySelectorAll('[data-job-group]').forEach(link=>{
  link.addEventListener('click',()=>{
    const selected=link.dataset.jobGroup||'';
    group.value=selected;
    updateTitles();
  });
});

const birthDay=document.querySelector('#birthDay');
const birthMonth=document.querySelector('#birthMonth');
const birthYear=document.querySelector('#birthYear');
const birthDateValue=document.querySelector('#birthDateValue');

function syncBirthDate(){
  const day=birthDay.value;
  const month=birthMonth.value;
  const year=birthYear.value;
  birthDateValue.value=(year&&month&&day)?`${year}/${month}/${day}`:'';
}
[birthDay,birthMonth,birthYear].forEach(field=>field.addEventListener('change',syncBirthDate));

const form=document.querySelector('#applyForm');
const statusBox=document.querySelector('#status');
const success=document.querySelector('#successBox');

form.addEventListener('submit',async event=>{
  event.preventDefault();
  syncBirthDate();

  if(!birthDateValue.value){
    statusBox.className='error';
    statusBox.textContent='تاریخ تولد شمسی را کامل انتخاب کنید.';
    return;
  }

  const button=form.querySelector('.form-submit');
  button.disabled=true;
  statusBox.className='muted';
  statusBox.textContent='در حال ثبت اطلاعات...';
  success.hidden=true;

  try{
    const response=await fetch('api/submit.php',{
      method:'POST',
      body:new FormData(form),
      headers:{'X-Requested-With':'fetch'}
    });
    const data=await response.json();

    if(!response.ok||!data.ok){
      throw new Error(data.message||'ثبت اطلاعات انجام نشد');
    }

    statusBox.textContent='';
    success.hidden=false;
    success.innerHTML=
      '<b>ثبت اولیه با موفقیت انجام شد ✅</b><br>'+
      'کد رهگیری: <b dir="ltr" class="tracking-code">'+data.code+'</b><br>'+
      'این کد را نگه دارید و ادامه ثبت‌نام و آزمون را داخل اپلیکیشن انجام دهید.<br><br>'+
      '<a class="btn primary" href="download.php">دانلود اپلیکیشن</a>';

    form.querySelectorAll('input,select,button').forEach(element=>element.disabled=true);
  }catch(error){
    statusBox.className='error';
    statusBox.textContent=error.message;
    button.disabled=false;
  }
});
</script>
</body>
</html>
