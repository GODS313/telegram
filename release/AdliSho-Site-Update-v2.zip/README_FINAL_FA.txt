AdliSho Bargh — نسخه نهایی cPanel
================================

آدرس نهایی سایت:
https://adlisho.online

آدرس نصب:
https://adlisho.online/installer.php

آدرس پنل مدیریت:
https://adlisho.online/admin/login.php

مخزن Worker متصل به Cloudflare:
https://github.com/GODS313/telegram

نصب سایت:
1) محتویات ZIP را مستقیماً داخل public_html استخراج کنید.
2) installer.php را باز کنید.
3) آدرس Worker جدیدی را که Cloudflare بعد از Deploy نمایش می‌دهد وارد کنید.
4) رمز مدیریت را تعیین و نصب را کامل کنید.
5) وارد پنل شوید و در «تنظیمات و Worker» تست سلامت و پیام آزمایشی را اجرا کنید.
6) پس از تست، installer.php را حذف یا تغییرنام دهید.

پنل مدیریت جدید:
- داشبورد آماری
- جست‌وجو، فیلتر وضعیت و صفحه‌بندی
- نمایش جزئیات پرونده و رسانه‌های احراز
- تأیید، رد و بررسی پرونده
- حذف کامل پرونده و فایل‌های مربوط
- تنظیم آدرس سایت، Worker، کلید اتصال و زمان نگهداری
- تغییر رمز و خروج امن
- تعویض APK، لوگو و بنر
- پاک‌سازی خودکار پرونده‌های منقضی‌شده

اتصال امن Worker:
- درخواست‌ها با HMAC-SHA256 امضا می‌شوند.
- TG_BOT_TOKEN و TG_CHAT_ID فقط در Secretهای Cloudflare قرار می‌گیرند.
- RELAY_SECRET باید در Cloudflare و پنل سایت یکسان باشد.
- اطلاعات حساس، IP، دستگاه، شماره تماس، کد ملی و رسانه‌ها به تلگرام ارسال نمی‌شوند.

فایل APK:
downloads/app.apk

راهنمای Worker:
README_WORKER_FA.txt
